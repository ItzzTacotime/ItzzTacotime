# **ProjectWebTerraria**
ProjectWebTerraria Is A Recreation Of Terraria That Will BE Playable On The Web

# **How To Play** 
[**WASD**] to move
[**Click**] to dig or place items
[**1,2,3,4,5,6**] Select Tool
[**R**] to reset your location

# **Screenhots**
![image](https://user-images.githubusercontent.com/101514210/231191461-603a9db3-5a90-4984-b89e-306054178ff3.png)
